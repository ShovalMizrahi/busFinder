package com.example.busfinder;

public class Bus {
    private String id;
    private String line;
    private double longtitude;
    private double latitude;
}
