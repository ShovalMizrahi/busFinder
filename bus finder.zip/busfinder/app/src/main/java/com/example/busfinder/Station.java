package com.example.busfinder;

public class Station {
    private long id;
    private String name;
    private City city;
    private double longtitude;
    private double latitude;


}
