package com.example.busfinder;

public class City {
    private long id;
    private String name;
}
