package com.example.busfinder;

public class Track {
    private String line;
    private Station station;
    private int order;
}
